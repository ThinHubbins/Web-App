





let balance = 0;
let dailyBudget = 0;
let expenseHistory = [];
let selectedCurrency = "USD"; // Default currency
const expenseList = document.getElementById('expenseList');
const balanceSpan = document.getElementById('balance');

document.addEventListener('DOMContentLoaded', () => {
    loadUserData();
});

function loadUserData() {
    // Load user data from local storage
    const storedBudget = localStorage.getItem('dailyBudget');
    const storedHistory = localStorage.getItem('expenseHistory');
    const storedCurrency = localStorage.getItem('selectedCurrency');

    if (storedBudget) {
        dailyBudget = parseFloat(storedBudget);
        balance = dailyBudget;
        balanceSpan.textContent = formatCurrency(balance);
    }

    if (storedHistory) {
        expenseHistory = JSON.parse(storedHistory);
        displayExpenseHistory();
    }

    if (storedCurrency) {
        selectedCurrency = storedCurrency;
    }

    updateCurrency();
}

function saveUserData() {
    localStorage.setItem('dailyBudget', dailyBudget);
    localStorage.setItem('expenseHistory', JSON.stringify(expenseHistory));
    localStorage.setItem('selectedCurrency', selectedCurrency);
}

function setBudget() {
    const budgetInput = document.getElementById('dailyBudget');
    const budget = parseFloat(budgetInput.value);

    if (isNaN(budget) || budget <= 0) {
        alert('Please enter a valid daily budget.');
        return;
    }

    dailyBudget = budget;
    balance = dailyBudget;
    balanceSpan.textContent = formatCurrency(balance);

    saveUserData();

    budgetInput.value = '';
}

function addExpense() {
    const amountInput = document.getElementById('expenseAmount');
    const descriptionInput = document.getElementById('expenseDescription');

    const amount = parseFloat(amountInput.value);
    const description = descriptionInput.value;

    if (isNaN(amount) || amount <= 0 || !description) {
        alert('Please enter a valid amount and description.');
        return;
    }

    if (amount > balance) {
        alert('Expense exceeds the remaining budget for the day. Please adjust your expense.');
        return;
    }

    const currentDate = new Date();
    const dateTime = currentDate.toLocaleString();

    balance -= amount;
    balanceSpan.textContent = formatCurrency(balance);

    const entry = `${formatCurrency(amount)} - ${description} (${dateTime})`;
    expenseHistory.push(entry);

    saveUserData();

    displayExpenseHistory();

    amountInput.value = '';
    descriptionInput.value = '';
    
    
    
    
    
}

function resetApp() {
    balance = 0;
    dailyBudget = 0;
    expenseHistory = [];
    selectedCurrency = "USD";

    balanceSpan.textContent = formatCurrency(balance);
    expenseList.innerHTML = '';

    document.getElementById('dailyBudget').value = '';
    document.getElementById('expenseAmount').value = '';
    document.getElementById('expenseDescription').value = '';

    saveUserData();
}

function displayExpenseHistory() {
    expenseList.innerHTML = '';
    expenseHistory.forEach((entry) => {
        const listItem = document.createElement('li');
        listItem.textContent = entry;
        expenseList.appendChild(listItem);
    });
}

function changeCurrency() {
    const currencyDropdown = document.getElementById('currency');
    selectedCurrency = currencyDropdown.value;

    updateCurrency();
    saveUserData();
}

function updateCurrency() {
    balanceSpan.textContent = formatCurrency(balance);
}

function formatCurrency(amount) {
    switch (selectedCurrency) {
        case "USD":
            return `$${amount.toFixed(2)}`;
        case "EUR":
            return `€${amount.toFixed(2)}`;
        case "GBP":
            return `£${amount.toFixed(2)}`;
        case "MXN":
            return `$${amount.toFixed(2)} MXN`;
        case "NGN":
            return `₦${amount.toFixed(2)}`;
        case "JPY":
            return `¥${amount.toFixed(2)}`;
        case "INR":
            return `₹${amount.toFixed(2)}`;
        case "AUD":
            return `A$${amount.toFixed(2)}`;
        case "CAD":
            return `CA$${amount.toFixed(2)}`;
        case "CNY":
            return `¥${amount.toFixed(2)}`;
        case "SEK":
            return `kr ${amount.toFixed(2)}`;
        case "NZD":
            return `NZ$${amount.toFixed(2)}`;
        case "SGD":
            return `S$${amount.toFixed(2)}`;
            
             case "INR":
            return `₹${amount.toFixed(2)}`; // Indian Rupee
        // ... (more cases) ...
        // Add more cases for other currencies as needed
        default:
            return `$${amount.toFixed(2)}`;
    }
}



// ... (previous code) ...

function addExpense() {
    const amountInput = document.getElementById('expenseAmount');
    const descriptionInput = document.getElementById('expenseDescription');

    const amount = parseFloat(amountInput.value);
    const description = descriptionInput.value;

    if (isNaN(amount) || amount <= 0 || !description) {
        alert('Please enter a valid amount and description.');
        return;
    }

    if (amount > balance) {
        // Display the popup when the user exceeds the budget
        showPopup('budgetExceedPopup');
        return;
    }

    const currentDate = new Date();
    const dateTime = currentDate.toLocaleString();

    balance -= amount;
    balanceSpan.textContent = formatCurrency(balance);

    const entry = `${formatCurrency(amount)} - ${description} (${dateTime})`;
    expenseHistory.push(entry);

    saveUserData();

    displayExpenseHistory();

    amountInput.value = '';
    descriptionInput.value = '';
}








// ... (previous code) ...

document.addEventListener('DOMContentLoaded', () => {
    loadUserData();
});

function loadUserData() {
    // Load user data from local storage
    const storedBudget = localStorage.getItem('dailyBudget');
    const storedHistory = localStorage.getItem('expenseHistory');
    const storedBalance = localStorage.getItem('balance');
    const storedCurrency = localStorage.getItem('selectedCurrency');

    if (storedBudget) {
        dailyBudget = parseFloat(storedBudget);
        balance = storedBalance ? parseFloat(storedBalance) : dailyBudget; // Use the stored balance if available
        balanceSpan.textContent = formatCurrency(balance);
    }

    if (storedHistory) {
        expenseHistory = JSON.parse(storedHistory);
        displayExpenseHistory();
    }

    if (storedCurrency) {
        selectedCurrency = storedCurrency;
    }

    updateCurrency();
}

function saveUserData() {
    localStorage.setItem('dailyBudget', dailyBudget);
    localStorage.setItem('expenseHistory', JSON.stringify(expenseHistory));
    localStorage.setItem('balance', balance); // Save the updated balance
    localStorage.setItem('selectedCurrency', selectedCurrency);
}

// ... (rest of the code) ...






















function showPopup(popupId) {
    const popup = document.getElementById(popupId);
    popup.style.display = 'block';
}

function closePopup() {
    const popup = document.getElementById('budgetExceedPopup');
    popup.style.display = 'none';
}

